//Inbuilt & External packages
const express = require("express");
const bodyParser = require("body-parser");
const path = require("path");
const session = require("express-session");
const cookieParser = require("cookie-parser");

//Database
const sequelize = require('./util/database');

//Routes
const authRoutes = require('./routes/auth_routes');
const userRoutes = require('./routes/user_routes');
const roleRoutes = require('./routes/role_routes');
const mentorRoutes = require('./routes/mentor_routes');
const otherRoutes = require('./routes/other_routes');

const oneDay = 1000 * 60 * 60 *24;
const app = express();

//Middlewares
app.use(express.static(path.join(__dirname, "public")));
app.use(bodyParser.urlencoded({extended:true}));

app.use(session({
    secret: "thisismysecretkey",
    saveUninitialized: true,
    cookie: {maxAge: oneDay},
    resave: false
}));
app.use(cookieParser());

app.set("view engine", "ejs");

app.locals.moment = require("moment");

//Main Routes
app.use('/auth', authRoutes);
app.use('/user', userRoutes);
app.use('/role', roleRoutes);
app.use('/mentor', mentorRoutes);
app.use(otherRoutes);


sequelize
    .sync()
    .then(result=>{
        // console.log(result);
    })
    .catch(err=>{
        console.log(err)
    })


app.listen(9999, ()=>console.log("Server started on port 9999"));