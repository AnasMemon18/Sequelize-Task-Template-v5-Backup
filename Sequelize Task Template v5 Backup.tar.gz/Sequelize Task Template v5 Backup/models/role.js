const Sequelize = require("sequelize");

const sequelize = require('../util/database');

const Role = sequelize.define('role', {
    roleId: {
        type: Sequelize.INTEGER,
        allowNull: false,
        autoIncrement: true,
        primaryKey: true
    },
    roleName: {
        type: Sequelize.STRING,
        allowNull: false,
        require: true
    }
})

module.exports = Role;