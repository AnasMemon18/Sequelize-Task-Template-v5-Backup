const Sequelize = require("sequelize");

const sequelize = require('../util/database');

const Mentor = sequelize.define('mentor', {
    mId: {
        type: Sequelize.INTEGER,
        primaryKey: true,
        autoIncrement: true,
    },
    mName: {
        type: Sequelize.STRING,
        allowNull: false,
        require: true
    },
    mEmail: {
        type: Sequelize.STRING,
        allowNull: false,
        require: true
    },
    mPassword: {
        type: Sequelize.STRING,
        allowNull: false,
        require: true
    },
    mTechnology: {
        type: Sequelize.STRING,
        allowNull: false,
        require: true
    },
    mPhoneNumber: {
        type: Sequelize.BIGINT,
        allowNull: false,
        require: true
    }
});

module.exports = Mentor;