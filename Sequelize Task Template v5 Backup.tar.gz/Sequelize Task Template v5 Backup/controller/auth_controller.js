const session = require("express-session");
const nodeMailer = require("nodemailer");

const User = require('../models/user');
var date = new Date().toISOString().split("T")[0];

var sentOtp;
var mainUserId;

const authLogin = async (req, res, next)=>{
    const user = await User.findOne({ where: { email: req.body.email } });
    try{
        if (user) {
            if(user.password === req.body.password){
            sess = req.session;
            sess.email = user.email;
            sess.name = user.name;
            res.redirect('/dashboard');
            }
            else{
                res.render("auth-login", {message: "Password incorrect. Please enter correct password."});
            }
        }
        else{
            res.render("auth-login", {message: "You are not a registered user, Please sign up."});
        }
    }catch(err){
        throw err;
    }   
};

const authLoginPage = (req, res, next)=>{
    res.render('auth-login');
}

const authRegisterPage = (req ,res, next)=>{
    res.render('auth-register', {date:date} );
}

const authRegister = async (req, res, next) => {
    try {
        const user = await User.findOne({ where: { email: req.body.email } });
        if (user) {
            console.log(user)
            res.render("index", {emailMessage: "Email already registered, Please try logging in."});
            // res.redirect('/');
        } else {
            User.create({
                name: req.body.name,
                email: req.body.email,
                password: req.body.confirmPassword,
                phoneNumber: req.body.phoneNumber,
                dob: req.body.dateOfBirth,
            })
                .then((user) => {
                    res.redirect('/auth/login-page');
                   
                })
                .catch(err => {
                    console.log("Insertion Error!");
                    throw err;
                })
        }
    }
    catch (err) {
        throw err;
    }
};


const authForgotPassPage = (req ,res , next)=>{
    res.render('auth-forgot');
};

const authForgot = async (req ,res, next)=>{
    const user = await User.findOne({ where: { email: req.body.email } });
    try{
        if(user){
            mainUserId = user.id;
            sentOtp =  Math.floor(1000+Math.random()*9000);

            var transporter = nodeMailer.createTransport({
                service: 'gmail',
                auth: {
                  user: 'anasmemon7864@gmail.com',
                  pass: 'aczq aqoc xbni smnr'
                }
              });

              var mailOptions = {
                from: 'anasmemon7864@gmail.com',
                to: user.email,
                subject: 'Otp sent from mentor for forgot password.',
                text: `Your Otp for forgot password: ${sentOtp}`
              };
              
              transporter.sendMail(mailOptions, function(error, info){
                if (error) {
                  console.log(error);
                } else {
                  console.log('Email sent: ' + info.response);
                }
              }); 
            console.log(sentOtp);

            res.render("auth-otp");
        }
        else{
            res.render('auth-forgot', {message: "Email doesn't exist."})
        }
    }catch(err){
        throw err;    
    }
};


const authOtp = (req, res, next)=>{
    var enteredOtp = parseInt(req.body.otp);
    // console.log(enteredOtp, " ", typeof(enteredOtp))

    if(enteredOtp == sentOtp){
        res.render("auth-pass-change");
    }
    else{
        res.render('auth-otp', {message: "Invalid Otp!"})
    }
};

const authChangePassword = (req, res, next)=>{
    try {
        User.update({
           password: req.body.confirmPassword
        }, {
            where: { id: mainUserId }
        }).then(user => {
            res.redirect('/auth/login-page');
        }).catch(err => {
            throw err;
        })
    } catch (err) {
        throw err;
    }
}


const logout = (req, res, next)=>{
    req.session.destroy((err)=>{
        if(err){
            throw err;
        }
        else{          
            res.redirect('/dashboard'); //This will go to other_routes.js
        }
    })
};


module.exports = {
    authLoginPage,
    authLogin,
    authRegisterPage,
    authRegister,
    authForgotPassPage,
    authForgot,
    authOtp,
    authChangePassword,
    logout
};