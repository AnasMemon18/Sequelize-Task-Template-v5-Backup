const Role = require('../models/role');

const addRolePage = (req, res, next)=>{
    res.render("addRole")
}

const addRole = (req, res, next)=>{
    try {
            Role.create({
               roleName: req.body.role
            })
                .then((role) => {
                    res.redirect('/user/showUsers');
                   
                })
                .catch(err => {
                    console.log("Insertion Error!");
                    throw err;
                })
        
    }
    catch (err) {
        throw err;
    }
}

module.exports = {
    addRolePage,
    addRole
};