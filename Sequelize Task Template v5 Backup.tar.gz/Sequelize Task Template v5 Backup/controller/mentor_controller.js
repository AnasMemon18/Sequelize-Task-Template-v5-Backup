const Mentor = require('../models/mentor');

const insertMentor = (req, res, next)=>{

}

module.exports = {
    insertMentor
};