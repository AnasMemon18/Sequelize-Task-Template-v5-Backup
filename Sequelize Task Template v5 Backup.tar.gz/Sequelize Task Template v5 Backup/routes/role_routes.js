const express = require("express");

const roleController = require('../controller/role_controller');

const router = express.Router();

router.get('/addRole-page', roleController.addRolePage);
router.post('/addRole', roleController.addRole);

module.exports = router;