const express = require("express");

const mentorController = require('../controller/mentor_controller');

const router = express.Router();

module.exports = router;