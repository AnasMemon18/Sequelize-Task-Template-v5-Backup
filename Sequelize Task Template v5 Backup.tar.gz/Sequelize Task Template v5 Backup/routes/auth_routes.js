const express = require("express");
const authController = require('../controller/auth_controller');

const router = express.Router();

router.get('/login-page', authController.authLoginPage);
router.get('/register-page', authController.authRegisterPage);
router.get('/forgot-password-page', authController.authForgotPassPage);
router.post('/authRegister', authController.authRegister);
router.post('/authLogin', authController.authLogin);
router.post('/authForgot', authController.authForgot);
router.post('/authOtp', authController.authOtp);
router.post('/authchangePassword', authController.authChangePassword);

router.get('/logout', authController.logout);


module.exports = router;