const express = require("express");

const router = express.Router();

router.get('/dashboard', (req, res, next)=>{
    var session = req.session;
    if(session.email  == undefined){
        res.redirect('/auth/login-page');
    }
    else{
        res.render('dashboard');
    }
});

router.get('/', (req, res, next)=>{
    res.render('auth-login');
});


module.exports = router;

